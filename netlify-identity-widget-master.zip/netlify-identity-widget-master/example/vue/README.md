# vue example

See [@medmin](https://github.com/medmin)'s vue example of using this widget:

- [github.com/whizjs/netlify-identity-demo-vue](https://github.com/whizjs/netlify-identity-demo-vue) (🌎 [example website](https://netlify-identity-demo-vue.netlify.com/))

Thanks [@medmin](https://github.com/medmin) 🙏
